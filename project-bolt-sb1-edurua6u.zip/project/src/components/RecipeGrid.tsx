import React from 'react';
import RecipeCard from './RecipeCard';
import { Recipe } from '../types';

interface RecipeGridProps {
  recipes: Recipe[];
  title?: string;
}

const RecipeGrid: React.FC<RecipeGridProps> = ({ recipes, title }) => {
  if (recipes.length === 0) {
    return (
      <div className="py-12 text-center">
        <h2 className="text-xl text-gray-600 dark:text-gray-300">
          No recipes found. Try a different search or category.
        </h2>
      </div>
    );
  }
  
  return (
    <div className="py-6">
      {title && (
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
          {title}
        </h2>
      )}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {recipes.map((recipe) => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}
      </div>
    </div>
  );
};

export default RecipeGrid;