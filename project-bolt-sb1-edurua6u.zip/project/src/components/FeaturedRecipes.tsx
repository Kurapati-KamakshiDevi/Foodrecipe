import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import RecipeCard from './RecipeCard';
import { getFeaturedRecipes } from '../data/recipes';

const FeaturedRecipes: React.FC = () => {
  const featuredRecipes = getFeaturedRecipes();
  
  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Featured Recipes
          </h2>
          <Link 
            to="/recipes" 
            className="flex items-center text-orange-500 hover:text-orange-600 transition-colors"
          >
            <span className="font-medium">View all</span>
            <ChevronRight className="ml-1 h-5 w-5" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {featuredRecipes.map((recipe) => (
            <RecipeCard key={recipe.id} recipe={recipe} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedRecipes;