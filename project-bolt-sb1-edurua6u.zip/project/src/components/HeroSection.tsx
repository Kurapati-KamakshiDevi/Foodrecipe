import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const HeroSection: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  return (
    <div className="relative bg-gradient-to-br from-orange-400 to-red-500 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute top-0 left-0 right-0 bottom-0 opacity-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgdmlld0JveD0iMCAwIDYwIDYwIj48ZyBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9IjAuNCIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBkPSJNMCAwaDYwdjYwSDB6Ii8+PHBhdGggZD0iTTMwIDMwYzE2LjU2OSAwIDMwLTEzLjQzMSAzMC0zMFY2MGgtNjBDMS4wNzMgNDIuMzkgMTMuNTMxIDMwIDMwIDMweiIgb3BhY2l0eT0iLjUiLz48cGF0aCBkPSJNMzAgMzBjLTE2LjU2OSAwLTMwIDEzLjQzMS0zMCAzMGg2MFYwYy0xNy4wOTcgMTcuNjEtMjkuNTU0IDMwLTMwIDMweiIgb3BhY2l0eT0iLjUiLz48L2c+PC9zdmc+')]"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 drop-shadow-sm">
            Discover Delicious <span className="text-yellow-300">Recipes</span>
          </h1>
          <p className="text-lg md:text-xl text-white opacity-90 max-w-2xl mx-auto mb-8">
            Find and share mouthwatering recipes for every occasion, meal, and diet preference. Start your culinary journey today!
          </p>
          
          <form onSubmit={handleSearch} className="max-w-lg mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for recipes, ingredients, or cuisines..."
                className="w-full pl-12 pr-4 py-4 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-orange-300 text-gray-800 text-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="absolute left-4 top-4">
                <Search className="h-6 w-6 text-gray-500" aria-hidden="true" />
              </div>
              <button
                type="submit"
                className="absolute right-2 top-2 bg-gradient-to-r from-orange-500 to-red-500 text-white font-medium px-6 py-2 rounded-full hover:from-orange-600 hover:to-red-600 transition-colors focus:outline-none focus:ring-2 focus:ring-orange-300"
              >
                Search
              </button>
            </div>
          </form>
          
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <span className="text-white">Popular: </span>
            <a href="/search?q=pasta" className="text-yellow-200 hover:text-white transition-colors mx-2">Pasta</a>
            <a href="/search?q=chicken" className="text-yellow-200 hover:text-white transition-colors mx-2">Chicken</a>
            <a href="/search?q=desserts" className="text-yellow-200 hover:text-white transition-colors mx-2">Desserts</a>
            <a href="/search?q=vegan" className="text-yellow-200 hover:text-white transition-colors mx-2">Vegan</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;