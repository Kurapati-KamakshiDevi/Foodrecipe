import React from 'react';
import { Clock, Users, ChefHat } from 'lucide-react';
import { Recipe } from '../types';

interface RecipeDetailsProps {
  recipe: Recipe;
}

const RecipeDetails: React.FC<RecipeDetailsProps> = ({ recipe }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-colors duration-300">
      <div className="relative h-72 sm:h-80 md:h-96">
        <img 
          src={recipe.image} 
          alt={recipe.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="mb-2">
            <span className="inline-block px-3 py-1 text-xs rounded-full bg-orange-500 text-white font-medium">
              {recipe.category}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white">
            {recipe.name}
          </h1>
          <p className="mt-2 text-sm sm:text-base text-gray-200">
            {recipe.description}
          </p>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-wrap gap-4 mb-8 text-sm">
          <div className="flex items-center">
            <Clock className="h-5 w-5 text-orange-500 mr-2" aria-hidden="true" />
            <div>
              <p className="text-gray-500 dark:text-gray-400">Total Time</p>
              <p className="font-medium text-gray-900 dark:text-white">{recipe.prepTime + recipe.cookTime} mins</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <Users className="h-5 w-5 text-orange-500 mr-2" aria-hidden="true" />
            <div>
              <p className="text-gray-500 dark:text-gray-400">Servings</p>
              <p className="font-medium text-gray-900 dark:text-white">{recipe.servings}</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <ChefHat className="h-5 w-5 text-orange-500 mr-2" aria-hidden="true" />
            <div>
              <p className="text-gray-500 dark:text-gray-400">Difficulty</p>
              <p className="font-medium text-gray-900 dark:text-white">{recipe.difficulty}</p>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <span className="w-8 h-8 bg-orange-100 dark:bg-orange-900 text-orange-500 rounded-full inline-flex items-center justify-center mr-2">
                1
              </span>
              Ingredients
            </h2>
            <ul className="space-y-2">
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index} className="flex items-start">
                  <span className="inline-block h-2 w-2 rounded-full bg-orange-500 mt-2 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">{ingredient}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <span className="w-8 h-8 bg-orange-100 dark:bg-orange-900 text-orange-500 rounded-full inline-flex items-center justify-center mr-2">
                2
              </span>
              Instructions
            </h2>
            <ol className="space-y-4">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex">
                  <span className="bg-orange-100 dark:bg-orange-900 text-orange-500 h-6 w-6 rounded-full inline-flex items-center justify-center font-medium mr-3 mt-0.5 flex-shrink-0">
                    {index + 1}
                  </span>
                  <p className="text-gray-700 dark:text-gray-300">{instruction}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Posted by {recipe.createdBy} on {new Date(recipe.createdAt).toLocaleDateString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetails;