import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '../components/LoginForm';

const LoginPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  
  const handleLogin = (email: string, password: string) => {
    setIsLoading(true);
    setError('');
    
    // Simulate login API call
    setTimeout(() => {
      if (email === 'user@example.com' && password === 'password') {
        // Mock successful login
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('user', JSON.stringify({ email }));
        navigate('/');
      } else {
        setError('Invalid email or password');
      }
      setIsLoading(false);
    }, 1000);
  };
  
  return (
    <div className="flex min-h-screen-minus-nav items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-900">
      <div className="w-full max-w-md">
        {error && (
          <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            {error}
          </div>
        )}
        
        <LoginForm onLogin={handleLogin} isLoading={isLoading} />
      </div>
    </div>
  );
};

export default LoginPage;