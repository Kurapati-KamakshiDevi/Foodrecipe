import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import RecipeDetails from '../components/RecipeDetails';
import { getRecipeById } from '../data/recipes';
import { Recipe } from '../types';

const RecipeDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    if (id) {
      // In a real app, this would be an API call
      const fetchedRecipe = getRecipeById(id);
      
      if (fetchedRecipe) {
        setRecipe(fetchedRecipe);
        // Update page title
        document.title = `${fetchedRecipe.name} - TastyBites`;
      } else {
        setError('Recipe not found');
      }
      
      setLoading(false);
    }
    
    // Cleanup function to reset the page title
    return () => {
      const defaultTitle = document.querySelector('title[data-default]')?.textContent;
      if (defaultTitle) document.title = defaultTitle;
    };
  }, [id]);
  
  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-64 bg-gray-300 dark:bg-gray-700 rounded-lg w-full mb-4"></div>
          <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-1/2"></div>
        </div>
      </div>
    );
  }
  
  if (error || !recipe) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Recipe Not Found
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            The recipe you're looking for might have been removed or doesn't exist.
          </p>
          <Link 
            to="/recipes" 
            className="inline-flex items-center text-orange-500 hover:text-orange-600 transition-colors"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Back to recipes
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-6">
        <Link 
          to="/recipes" 
          className="inline-flex items-center text-orange-500 hover:text-orange-600 transition-colors"
        >
          <ChevronLeft className="h-5 w-5 mr-1" />
          Back to recipes
        </Link>
      </div>
      
      <RecipeDetails recipe={recipe} />
    </div>
  );
};

export default RecipeDetailPage;