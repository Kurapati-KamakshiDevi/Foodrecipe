import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import CategoryFilter from '../components/CategoryFilter';
import RecipeGrid from '../components/RecipeGrid';
import { getRecipesByCategory } from '../data/recipes';

const RecipesPage: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const categoryParam = queryParams.get('category') || 'All';
  
  const [selectedCategory, setSelectedCategory] = useState(categoryParam);
  
  useEffect(() => {
    // Update category when URL param changes
    setSelectedCategory(categoryParam);
  }, [categoryParam]);
  
  const recipes = getRecipesByCategory(selectedCategory);
  
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    
    // Update URL with the new category parameter
    const searchParams = new URLSearchParams(location.search);
    if (category === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', category);
    }
    
    const newUrl = `${location.pathname}${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          {selectedCategory === 'All' ? 'All Recipes' : `${selectedCategory} Recipes`}
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Browse our collection of delicious {selectedCategory.toLowerCase() === 'all' ? '' : selectedCategory.toLowerCase()} recipes
        </p>
      </div>
      
      <CategoryFilter 
        selectedCategory={selectedCategory} 
        onCategoryChange={handleCategoryChange} 
      />
      
      <RecipeGrid recipes={recipes} />
    </div>
  );
};

export default RecipesPage;