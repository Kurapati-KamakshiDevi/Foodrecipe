import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Search } from 'lucide-react';
import RecipeGrid from '../components/RecipeGrid';
import { searchRecipes } from '../data/recipes';
import { Recipe } from '../types';

const SearchPage: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get('q') || '';
  
  const [query, setQuery] = useState(searchQuery);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  
  useEffect(() => {
    if (searchQuery) {
      const results = searchRecipes(searchQuery);
      setRecipes(results);
      
      // Update title
      document.title = `Search results for "${searchQuery}" - TastyBites`;
    }
    
    // Reset query state when URL parameter changes
    setQuery(searchQuery);
    
    // Cleanup
    return () => {
      const defaultTitle = document.querySelector('title[data-default]')?.textContent;
      if (defaultTitle) document.title = defaultTitle;
    };
  }, [searchQuery]);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      // Update URL with the new search query
      const newUrl = `/search?q=${encodeURIComponent(query)}`;
      window.history.pushState({ path: newUrl }, '', newUrl);
      
      // Update results
      const results = searchRecipes(query);
      setRecipes(results);
    }
  };
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          {searchQuery ? `Search results for "${searchQuery}"` : 'Search Recipes'}
        </h1>
        
        <form onSubmit={handleSearch} className="max-w-2xl">
          <div className="relative">
            <input
              type="text"
              placeholder="Search recipes, ingredients, or cuisines..."
              className="w-full pl-10 pr-4 py-3 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-orange-500 dark:bg-gray-700 dark:text-white"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <div className="absolute left-3 top-3">
              <Search className="h-5 w-5 text-gray-400" aria-hidden="true" />
            </div>
            <button
              type="submit"
              className="absolute right-2 top-2 bg-orange-500 text-white font-medium px-4 py-1 rounded-md hover:bg-orange-600 transition-colors focus:outline-none focus:ring-2 focus:ring-orange-300"
            >
              Search
            </button>
          </div>
        </form>
      </div>
      
      {searchQuery && (
        <div className="mb-4">
          <p className="text-gray-600 dark:text-gray-300">
            Found {recipes.length} {recipes.length === 1 ? 'recipe' : 'recipes'} matching your search
          </p>
        </div>
      )}
      
      {searchQuery && <RecipeGrid recipes={recipes} />}
    </div>
  );
};

export default SearchPage;