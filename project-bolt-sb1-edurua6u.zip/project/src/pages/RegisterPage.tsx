import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RegisterForm from '../components/RegisterForm';

const RegisterPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  
  const handleRegister = (username: string, email: string, password: string) => {
    setIsLoading(true);
    setError('');
    
    // Simulate register API call
    setTimeout(() => {
      // In a real app, this would validate and register the user
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('user', JSON.stringify({ username, email }));
      navigate('/');
      setIsLoading(false);
    }, 1000);
  };
  
  return (
    <div className="flex min-h-screen-minus-nav items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-900">
      <div className="w-full max-w-md">
        {error && (
          <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            {error}
          </div>
        )}
        
        <RegisterForm onRegister={handleRegister} isLoading={isLoading} />
      </div>
    </div>
  );
};

export default RegisterPage;