import { Recipe } from '../types';

export const recipes: Recipe[] = [
  {
    id: '1',
    name: 'Creamy Garlic Parmesan Pasta',
    description: 'A rich and creamy pasta dish with garlic and parmesan cheese.',
    category: 'Pasta',
    cookTime: 15,
    prepTime: 10,
    difficulty: 'Easy',
    servings: 4,
    ingredients: [
      '8 oz fettuccine pasta',
      '2 tbsp butter',
      '4 cloves garlic, minced',
      '1 cup heavy cream',
      '1 cup grated parmesan cheese',
      'Salt and pepper to taste',
      '2 tbsp chopped fresh parsley'
    ],
    instructions: [
      'Cook pasta according to package directions. Drain and set aside.',
      'In a large skillet, melt butter over medium heat. Add garlic and sauté for 1 minute until fragrant.',
      'Pour in heavy cream and bring to a simmer. Cook for 2 minutes until slightly thickened.',
      'Reduce heat to low and add parmesan cheese. Stir until melted and smooth.',
      'Season with salt and pepper to taste.',
      'Add cooked pasta to the sauce and toss until well coated.',
      'Garnish with fresh parsley before serving.'
    ],
    image: 'https://images.pexels.com/photos/1527603/pexels-photo-1527603.jpeg',
    isFeatured: true,
    createdAt: '2023-10-15',
    createdBy: 'Chef Maria'
  },
  {
    id: '2',
    name: 'Grilled Lemon Herb Chicken',
    description: 'Juicy grilled chicken with bright lemon and herb flavors.',
    category: 'Main Course',
    cookTime: 20,
    prepTime: 60,
    difficulty: 'Medium',
    servings: 4,
    ingredients: [
      '4 boneless, skinless chicken breasts',
      '3 tbsp olive oil',
      '2 lemons, juiced and zested',
      '3 cloves garlic, minced',
      '1 tbsp fresh thyme, chopped',
      '1 tbsp fresh rosemary, chopped',
      '1 tsp salt',
      '1/2 tsp black pepper'
    ],
    instructions: [
      'In a bowl, combine olive oil, lemon juice, lemon zest, garlic, thyme, rosemary, salt, and pepper.',
      'Place chicken in a large zip-top bag and pour marinade over it. Seal and refrigerate for at least 1 hour, up to overnight.',
      'Preheat grill to medium-high heat.',
      'Remove chicken from marinade and grill for 6-7 minutes per side, or until internal temperature reaches 165°F.',
      'Let rest for 5 minutes before serving.'
    ],
    image: 'https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg',
    isFeatured: true,
    createdAt: '2023-09-20',
    createdBy: 'Chef Alex'
  },
  {
    id: '3',
    name: 'Berry Breakfast Smoothie Bowl',
    description: 'Nutritious and delicious smoothie bowl packed with berries and toppings.',
    category: 'Breakfast',
    cookTime: 0,
    prepTime: 10,
    difficulty: 'Easy',
    servings: 1,
    ingredients: [
      '1 frozen banana',
      '1 cup mixed frozen berries',
      '1/2 cup Greek yogurt',
      '1/4 cup almond milk',
      '1 tbsp honey',
      'Toppings: fresh berries, granola, chia seeds, sliced almonds'
    ],
    instructions: [
      'Add frozen banana, mixed berries, Greek yogurt, almond milk, and honey to a blender.',
      'Blend until smooth and creamy. Add more almond milk if needed for desired consistency.',
      'Pour into a bowl and top with fresh berries, granola, chia seeds, and sliced almonds.'
    ],
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg',
    isFeatured: false,
    createdAt: '2023-11-05',
    createdBy: 'Nutritionist Sarah'
  },
  {
    id: '4',
    name: 'Classic Chocolate Chip Cookies',
    description: 'Soft and chewy chocolate chip cookies with a golden edge.',
    category: 'Dessert',
    cookTime: 12,
    prepTime: 15,
    difficulty: 'Easy',
    servings: 24,
    ingredients: [
      '2 1/4 cups all-purpose flour',
      '1 tsp baking soda',
      '1 tsp salt',
      '1 cup (2 sticks) unsalted butter, softened',
      '3/4 cup granulated sugar',
      '3/4 cup packed brown sugar',
      '2 large eggs',
      '2 tsp vanilla extract',
      '2 cups semi-sweet chocolate chips'
    ],
    instructions: [
      'Preheat oven to 375°F and line baking sheets with parchment paper.',
      'In a small bowl, whisk together flour, baking soda, and salt.',
      'In a large bowl, beat butter and both sugars until creamy.',
      'Add eggs one at a time, then vanilla, beating well after each addition.',
      'Gradually mix in the flour mixture until just combined.',
      'Stir in chocolate chips.',
      'Drop by rounded tablespoons onto baking sheets, about 2 inches apart.',
      'Bake for 9-12 minutes until edges are golden but centers are still soft.',
      'Cool on baking sheets for 2 minutes, then transfer to wire racks to cool completely.'
    ],
    image: 'https://images.pexels.com/photos/230325/pexels-photo-230325.jpeg',
    isFeatured: true,
    createdAt: '2023-08-12',
    createdBy: 'Baker John'
  },
  {
    id: '5',
    name: 'Mediterranean Quinoa Salad',
    description: 'Fresh and healthy quinoa salad with Mediterranean flavors.',
    category: 'Salad',
    cookTime: 15,
    prepTime: 15,
    difficulty: 'Easy',
    servings: 6,
    ingredients: [
      '1 cup quinoa, rinsed',
      '2 cups water',
      '1 cucumber, diced',
      '1 pint cherry tomatoes, halved',
      '1/2 red onion, finely diced',
      '1/2 cup kalamata olives, pitted and sliced',
      '1/2 cup feta cheese, crumbled',
      '1/4 cup fresh parsley, chopped',
      '1/4 cup fresh mint, chopped',
      '3 tbsp olive oil',
      '2 tbsp lemon juice',
      '1 tsp dried oregano',
      'Salt and pepper to taste'
    ],
    instructions: [
      'In a medium saucepan, combine quinoa and water. Bring to a boil, then reduce heat and simmer covered for 15 minutes until water is absorbed.',
      'Fluff quinoa with a fork and let cool to room temperature.',
      'In a large bowl, combine cooled quinoa, cucumber, tomatoes, red onion, olives, feta, parsley, and mint.',
      'In a small bowl, whisk together olive oil, lemon juice, oregano, salt, and pepper.',
      'Pour dressing over salad and toss gently to combine.',
      'Serve immediately or refrigerate for up to 3 days.'
    ],
    image: 'https://images.pexels.com/photos/1211887/pexels-photo-1211887.jpeg',
    isFeatured: false,
    createdAt: '2023-07-30',
    createdBy: 'Nutritionist Sarah'
  },
  {
    id: '6',
    name: 'Spicy Thai Red Curry',
    description: 'Aromatic and spicy Thai red curry with vegetables and your choice of protein.',
    category: 'Main Course',
    cookTime: 25,
    prepTime: 15,
    difficulty: 'Medium',
    servings: 4,
    ingredients: [
      '2 tbsp vegetable oil',
      '2-3 tbsp Thai red curry paste',
      '1 can (14 oz) coconut milk',
      '1 cup vegetable or chicken broth',
      '1 lb protein of choice (chicken, tofu, shrimp)',
      '1 red bell pepper, sliced',
      '1 zucchini, sliced',
      '1 carrot, thinly sliced',
      '1/2 onion, sliced',
      '2 tbsp fish sauce (or soy sauce)',
      '1 tbsp brown sugar',
      '1 lime, juiced',
      'Fresh basil leaves',
      'Steamed rice, for serving'
    ],
    instructions: [
      'Heat oil in a large pot over medium heat. Add curry paste and cook for 1 minute until fragrant.',
      'Stir in coconut milk and broth, bring to a simmer.',
      'Add protein and cook until nearly done (about 5 minutes for chicken, 3 minutes for shrimp, or 2 minutes for tofu).',
      'Add vegetables and cook for 5-7 minutes until tender-crisp.',
      'Stir in fish sauce, brown sugar, and lime juice. Adjust seasoning to taste.',
      'Garnish with fresh basil leaves and serve over steamed rice.'
    ],
    image: 'https://images.pexels.com/photos/699953/pexels-photo-699953.jpeg',
    isFeatured: true,
    createdAt: '2023-10-05',
    createdBy: 'Chef Alex'
  }
];

export const categories = [
  'All',
  'Breakfast',
  'Main Course',
  'Pasta',
  'Salad',
  'Dessert'
];

export const getFeaturedRecipes = (): Recipe[] => {
  return recipes.filter(recipe => recipe.isFeatured);
};

export const getRecipeById = (id: string): Recipe | undefined => {
  return recipes.find(recipe => recipe.id === id);
};

export const getRecipesByCategory = (category: string): Recipe[] => {
  if (category === 'All') {
    return recipes;
  }
  return recipes.filter(recipe => recipe.category === category);
};

export const searchRecipes = (query: string): Recipe[] => {
  const lowercaseQuery = query.toLowerCase();
  return recipes.filter(recipe => 
    recipe.name.toLowerCase().includes(lowercaseQuery) || 
    recipe.description.toLowerCase().includes(lowercaseQuery) ||
    recipe.ingredients.some(ingredient => ingredient.toLowerCase().includes(lowercaseQuery))
  );
};