export interface Recipe {
  id: string;
  name: string;
  description: string;
  category: string;
  cookTime: number;
  prepTime: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  servings: number;
  ingredients: string[];
  instructions: string[];
  image: string;
  isFeatured: boolean;
  createdAt: string;
  createdBy: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  savedRecipes: string[];
}

export type ThemeMode = 'light' | 'dark';